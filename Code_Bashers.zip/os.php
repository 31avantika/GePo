<html>

<head>

<title>Quiz Questions And Answers</title>

</head>

<body>

<center><h1>Quiz Questions on OS</h1></center>

<p>

<form name="quiz">

<p>

<b>Question 1.

<br>What is SMP?<br></b>

<blockquote>

<input type="radio" name="q1" value="Systematic Multple Processing">Systematic Multple Processing<br>

<input type="radio" name="q1" value="Symmetric Multi Processing">Symmetric Multi Processing<br>

<input type="radio" name="q1" value="Serial Multi Processing">Serial Multi Processing<br>

</blockquote>

<p><b>

<hr>

Question 2.

<br>RAID 1 describes?<br></b>

<blockquote>

<input type="radio" name="q2" value="Bit-interleaved Parity">Bit-interleaved Parity<br>

<input type="radio" name="q2" value="P+Q Redundancy">P+Q Redundancy<br>

<input type="radio" name="q2" value="Mirrored Disks">Mirrored Disks<br>

</blockquote>

<p><b>

<hr>

Question 3.

<br>What are overlays?<br></b>

<blockquote>

<input type="radio" name="q3" value="Enabling a process to be larger than the amount of memory allocated to it.">Enabling a process to be larger than the amount of memory allocated to it.<br>

<input type="radio" name="q3" value="Enabling a process to be smaller than the amount of memory allocated to it.">Enabling a process to be smaller than the amount of memory allocated to it.<br>

<input type="radio" name="q3" value="Adding layers to a process">Adding layers to a process<br>

</blockquote>

<p><b>

<hr>

Question 4.

<br>When does thrashing occur?<br></b>

<blockquote>

<input type="radio" name="q4" value="Thrashing refers to an instance of high paging activity.">Thrashing refers to an instance of high paging activity.<br>

<input type="radio" name="q4" value="Thrashing refers to an instance of no paging activity at all.">Thrashing refers to an instance of no paging activity at all.<br>

<input type="radio" name="q4" value="Thrashing refers to an instance of fragmentation.">Thrashing refers to an instance of fragmentation.<br>

</blockquote>

<p><b>

<hr>

Question 5.

<br>What is a folder in Ubuntu?<br></b>

<blockquote>

<input type="radio" name="q5" value="A collection of files.">A collection of files.<br>

<input type="radio" name="q5" value="There is no concept of Folder in Ubuntu.">There is no concept of Folder in Ubuntu.<br>

<input type="radio" name="q5" value="Collection of directories.">Collection of directories.<br>

</blockquote>

<p><b>


<p><b>

<input type="button"value="Grade Me"onClick="getScore(this.form);">

<input type="reset" value="Clear"><p>

Number of score out of 5 = <input type= text size 5 name= "mark">

Score in percentage = <input type=text size=5 name="percentage"><br>

</form>

<p>

<form method="post" name="Form" onsubmit="" action="">

</form>

</body>

<script>

var numQues = 5;

var numChoi = 3;

var answers = new Array(5);

answers[0] = "Symmetric Multi Processing";

answers[1] = "Mirrored Disks";

answers[2] = "Enabling a process to be larger than the amount of memory allocated to it.";

answers[3] = "Thrashing refers to an instance of high paging activity.";

answers[4] = "There is no concept of Folder in Ubuntu.";

function getScore(form) {

var score = 0;

var currElt;

var currSelection;

for (i=0; i<numQues; i++) {

currElt = i*numChoi;

answered=false;

for (j=0; j<numChoi; j++) {

currSelection = form.elements[currElt + j];

if (currSelection.checked) {

answered=true;

if (currSelection.value == answers[i]) {

score++;

break;

}

}

}

if (answered ===false){alert("Do answer all the questions, Please") ;return false;}

}

var scoreper = Math.round(score/numQues*100);

form.percentage.value = scoreper + "%";

form.mark.value=score;

if (scoreper < 80){alert("Better luck next time!! Refer to https://www.w3schools.com/:)") ;return false;}

}

</script>

</html>