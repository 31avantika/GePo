<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>contact</title>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header-wrap">
	<div class="logo">
		<h1>GE-PO</h1>
    </div>
</div><!---header-wrap-End--->
<div class="menu-wrap">
  <div class="menu">
    <ul>
          	<li><a href="index.php" >Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="apply.php" >Apply</a></li>
            <li><a href="post.php">Post</a></li>
            <li><a href="contact.php"class="active">Contact</a></li>
    </ul>
  </div>
  <div class="socia-wrap">
    <div class="socail">
      <ul>
        <li><a href="#"><img src="images/facebook.png" alt="" /></a></li>
        <li><a href="#"><img src="images/twwtter.png" alt="" /></a></li>
        <li><a href="#"><img src="images/linkedin.png" alt="" /></a></li>
      </ul>
    </div>
  </div>
</div>
<!---menu-wrap-End--->

  <div class="jumbotron" style="	background-color:black;">
  <h1   style="color:white;font-family:impact;font-size: 40pt;"><CENTER>	CONTACT</CENTER></h1>
  <font style="ont-family:cursive;font-size:18pt" ><CENTER>FOR ANY KIND OF COMPLAIN OR ANY KIND OF SUGGESTIONS</CENTER></font>
</div>
     
	  
	  <center><div class="card" >
	  <img src="images/icon5.png "alt=""style="width:2.5% ">
	  <div class="container">
	  <h4 style="font-size:18px">DIBYA RANJAN DAS</h4>
	  <p>Founder<br>Senior Developer<a href="dibya911das@gmail.com"><br>Gmail:<u>dibya911das@gmail.com</u><br></a>mobile no-7979393969</p>
	  </div><br>
	  <img src="images/icon5.png "alt=""style="width:2.5%">
	  <div class="container">
	  <h4 style="font-size:18px">AVANTIKA MISHRA</h4>
	  <p>CO-FOUNDER<br>asistant developer<br>Gmail:<a href="avantikamishra31.am@gmail.com"><u>avantikamishra31.am@gmail.com</u><br></a>mobile no-9999373966</p><br><br><br>
	  </div>
	  </div></center>
 
  <div class="jumbotron" style="	background-color:black ;padding-left:200px">
  <font style="font-family:cursive;font-size:18pt" >FOR ANY QUERIES</font>
</div>

       <form>
          <div class="contact-form mar-top30">
            <label> <span>Full name</span>
            <input type="text" class="input_text" name="name" id="name"/>
            </label>
            <label> <span>Email</span>
            <input type="text" class="input_text" name="email" id="email"/>
            </label>
            <label> <span>Subject</span>
            <input type="text" class="input_text" name="subject" id="subject"/>
            </label>
            <label> <span>Message</span>
            <textarea class="message" name="feedback" id="feedback"></textarea>
            <input   type="button" class="button" value="Submit Form" />
            </label>
          </div>
        </form>
        <div class="clearing"></div>
      </div>
  </div>	
  </div>
</body>
</html>
