<html>

<head>

<title>Quiz Questions And Answers</title>

</head>

<body>

<center><h1>Quiz Questions on DBMS</h1></center>

<p>

<form name="quiz">

<p>

<b>Question 1.

<br>What is the purpose of normalization in DBMS?<br></b>

<blockquote>

<input type="radio" name="q1" value="To minimize the redundancy of the Data.">To minimize the redundancy of the Data.<br>

<input type="radio" name="q1" value="To minimize the Insert, Delete and Update Anomalies.">To minimize the Insert, Delete and Update Anomalies.<br>

<input type="radio" name="q1" value="All of the above">All of the above<br>

</blockquote>

<p><b>

<hr>

Question 2.

<br>What is the main difference between UNION and UNION ALL?<br></b>

<blockquote>

<input type="radio" name="q2" value="Both are same">Both are same<br>

<input type="radio" name="q2" value="UNION removes duplicate rows, UNION ALL does not remove the duplicate rows">UNION removes duplicate rows, UNION ALL does not remove the duplicate rows<br>

<input type="radio" name="q2" value="UNION is deprecated now, while UNION ALL is not">UNION is deprecated now, while UNION ALL is not<br>

</blockquote>

<p><b>

<hr>

Question 3.

<br>ACID properties in DBMS stand for __________________<br></b>

<blockquote>

<input type="radio" name="q3" value="Atomicity, Consistency, Isolation, and Durability">Atomicity, Consistency, Isolation, and Durability<br>

<input type="radio" name="q3" value="Attributes, Columns, Isolation, and Dynamic">Attributes, Columns, Isolation, and Dynamic<br>

<input type="radio" name="q3" value="Additional, Catalytic, Irrecursive and Drastic">Additional, Catalytic, Irrecursive and Drastic<br>

</blockquote>

<p><b>

<hr>

Question 4.

<br>What are the levels of abstraction in DBMS?<br></b>

<blockquote>

<input type="radio" name="q4" value="Private, Public, Protected">Private, Public, Protected<br>

<input type="radio" name="q4" value="Physical, Logical, View">Physical, Logical, View<br>

<input type="radio" name="q4" value="Level 1, Level 2, Level 3">Level 1, Level 2, Level 3<br>

</blockquote>

<p><b>

<hr>

Question 5.

<br>What is BCNF in the DBMS?<br></b>

<blockquote>

<input type="radio" name="q5" value="Before Communication Network Form">Before Communication Network Form<br>

<input type="radio" name="q5" value="Between Column Nested Form">Between Column Nested Form<br>

<input type="radio" name="q5" value="Boyce Codd Normal Form">Boyce Codd Normal Form<br>

</blockquote>

<p><b>


<p><b>

<input type="button"value="Grade Me"onClick="getScore(this.form);">

<input type="reset" value="Clear"><p>

Number of score out of 5 = <input type= text size 5 name= "mark">

Score in percentage = <input type=text size=5 name="percentage"><br>

</form>

<p>

<form method="post" name="Form" onsubmit="" action="">

</form>

</body>

<script>

var numQues = 5;

var numChoi = 3;

var answers = new Array(5);

answers[0] = "All of the above";

answers[1] = "UNION removes duplicate rows, UNION ALL does not remove the duplicate rows";

answers[2] = "Atomicity, Consistency, Isolation, and Durability";

answers[3] = "Physical, Logical, View";

answers[4] = "Boyce Codd Normal Form";

function getScore(form) {

var score = 0;

var currElt;

var currSelection;

for (i=0; i<numQues; i++) {

currElt = i*numChoi;

answered=false;

for (j=0; j<numChoi; j++) {

currSelection = form.elements[currElt + j];

if (currSelection.checked) {

answered=true;

if (currSelection.value == answers[i]) {

score++;

break;

}

}

}

if (answered ===false){alert("Do answer all the questions, Please") ;return false;}

}

var scoreper = Math.round(score/numQues*100);

form.percentage.value = scoreper + "%";

form.mark.value=score;

if (scoreper < 80){alert("Better luck next time!! Refer to https://www.w3schools.com/ :)") ;return false;}

}

</script>

</html>