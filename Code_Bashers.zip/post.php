<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>post</title>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<script>
// When the user clicks on <div>, open the popup
function fn() {
alert("submitted");
}
</script>
</head>

<body>
<div class="header-wrap">
  <div class="logo">
    <h1>GE-PO</h1>
  </div>
</div>

<div class="menu-wrap">
  <div class="menu">
    <ul>
          	<li><a href="index.php" >Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="apply.php">Apply</a></li>
            <li><a href="post.php"class="active">Post</a></li>
            <li><a href="contact.php">Contact</a></li>
    </ul>
  </div>
  <div class="socia-wrap">
    <div class="socail">
      <ul>
        <li><a href="#"><img src="images/facebook.png" alt="" /></a></li>
        <li><a href="#"><img src="images/twwtter.png" alt="" /></a></li>
        <li><a href="#"><img src="images/linkedin.png" alt="" /></a></li>
      </ul>
    </div>
  </div>
</div>
<!---menu-wrap-End--->


<h1 style="color:white" >POST YOUR JOB DETAILS HERE</h1>
<center>
   <form method="post" action="apply.php" >
          <div class="contact-form mar-top30" >
            <label> <span>COMPANY NAME</span>
            <input type="text" class="input_text" name="nm" placeholder="enter here your company's name" />
            </label>
            <label> <span>JOB SPECIFICATION</span>
			<input type="text" class="input_text" name="jd" placeholder="enter here your job specification"/>
            
            </label>
            <label> <span>DURATION</span>
            <input type="text" class="input_text" name="time" placeholder="job duration" />
            </label>
            <label> <span>STIPEND</span>
            <input type="text" class="input_text" name="money" placeholder="stipened per month"/><br><br>
			<input type="submit" onclick="fn()" value="submit">
			
            </label>
          </div>
        </form>
</center>



<div class="clearing"></div>



   

</body>
</html>
