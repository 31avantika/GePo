
<html>

<head>

<title>Quiz Questions And Answers</title>

</head>

<body>

<center><h1>Quiz Questions</h1></center>

<p>

<form name="quiz">

<p>

<b>Question 1.

<br>HTML stands for ___________<br></b>

<blockquote>

<input type="radio" name="q1" value="HYPER TEXT MARKUP LANGAUAGE ">HYPER TEXT MARKUP LANGAUAGE <br>

<input type="radio" name="q1" value="HYPER TRANSFER MARKUP LANGUAGE">HYPER TRANSFER MARKUP LANGUAGE<br>

<input type="radio" name="q1" value="HIGHLEVEL TEXT  MAKING LANGUAGE">HIGHLEVEL TEXT  MAKING LANGUAGE<br>

</blockquote>

<p><b>

<hr>

Question 2.

<br>IDE is a _____________<br></b>

<blockquote>

<input type="radio" name="q2" value="command-language interface based tool">command-language interface based tool<br>

<input type="radio" name="q2" value="GUI based tool">GUI based tool<br>

<input type="radio" name="q2" value="menus based tool">menus based tool<br>

</blockquote>

<p><b>

<hr>

Question 3.

<br>Why css is used ?  <br></b>

<blockquote>

<input type="radio" name="q3" value="desgning algorithim">desgning algorithim<br>

<input type="radio" name="q3" value="designing webpage">designing webpage<br>

<input type="radio" name="q3" value="designing database">designing database<br>

</blockquote>

<p><b>

<hr>

Question 4.

<br>What do you mean by Dangling Pages?<br></b>

<blockquote>

<input type="radio" name="q4" value="The page that does not have any inlinks">The page that does not have any inlinks<br>

<input type="radio" name="q4" value="The page that does not have any outlinks">The page that does not have any outlinks<br>

<input type="radio" name="q4" value="The page that does not have any other data format other than text">The page that does not have any other data format other than text<br>

</blockquote>

<p><b>

<hr>

Question 5.

<br>why bootstrap is used?<br></b>

<blockquote>

<input type="radio" name="q5" value="to make web design easier">to make web design easier<br>

<input type="radio" name="q5" value="to make website elastic">to make website elastic<br>

<input type="radio" name="q5" value="both option">both option>

</blockquote>

<p><b>


<p><b>

<input type="button"value="Grade Me"onClick="getScore(this.form);">

<input type="reset" value="Clear"><p>

Number of score out of 5 = <input type= text size 5 name= "mark">

Score in percentage = <input type=text size=5 name="percentage"><br>

</form>

<p>

<form method="post" name="Form" onsubmit="" action="">

</form>

</body>

<script>

var numQues = 5;

var numChoi = 3;

var answers = new Array(5);

answers[0] = "HYPER TEXT MARKUP LANGAUAGE";

answers[1] = "GUI based tool";

answers[2] = "designing webpage";

answers[3] = "The page that does not have any outlinks";

answers[4] = "both option";

function getScore(form) {

var score = 0;

var currElt;

var currSelection;

for (i=0; i<numQues; i++) {

currElt = i*numChoi;

answered=false;

for (j=0; j<numChoi; j++) {

currSelection = form.elements[currElt + j];

if (currSelection.checked) {

answered=true;

if (currSelection.value == answers[i]) {

score++;

break;

}

}

}

if (answered ===false){alert("Do answer all the questions, Please") ;return false;}

}

var scoreper = Math.round(score/numQues*100);

form.percentage.value = scoreper + "%";

form.mark.value=score;

if (scoreper < 80){alert("Better luck next time!!  and learn thins kind of demanded web dessign at w3schools.com:)") ;return false;}

}

</script>

</html>
