<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>about</title>
<link href="css/styles.css" rel="stylesheet" type="text/css" />
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
</head>
<body>

<div class="header-wrap">
	<div class="logo">
		<h1 >GE-PO</h1>
    </div>
</div><!---header-wrap-End--->

<div class="menu-wrap">
	<div class="menu">
		<ul>
          	<li><a href="index.php" >Home</a></li>
            <li><a href="about.php" class="active">About</a></li>
            <li><a href="apply.php">Apply</a></li>
            <li><a href="post.php">Post</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </div>
    
    <div class="socia-wrap">
	<div class="socail">
		<ul>
        	<li><a href="#"><img src="images/facebook.png" alt="" /></a></li>
            <li><a href="#"><img src="images/twwtter.png" alt="" /></a></li>
            <li><a href="#"><img src="images/linkedin.png" alt="" /></a></li>
		</ul>
	</div>
</div>
</div><!---menu-wrap-End--->


  	<div class="title">
  		<h1>About Us</h1>
    </div>
  	<div class="container" >
<p style="font-size:20px; color:#ffffff">There is no doubt that multinationals like Microsoft, Amazon and Google are ruling the technology sector. Any new product that has been launched in the market, irrespective of it's success or failure, is stereotyped to be launched by these leaders.
Indeed now there are companies or start ups coming up, struggling to compete with these product based multinationals, and many of them have succeeded to impress the audience too, which results in an increase in competition for even these tech giants.
But why do you think it is like so?<br>
It is because these companies have established their brand names in the market, and played with the minds of the audience so much, that every new product, good or bad, is stereotyped to be theirs.<br>
<br>
Is there any Indian company which has been successful to establish itself up to this height?
<br>
The reason is scarcity of emerging start ups in India.<br>
The creme layer technocrats, produced from the most premium and fine institutes of the nation, choose to work for these product based companies. And hence, the companies of the nation are devoid of those premium brains.
<br>
What do you think are the start up hubs in India?
<br>
Is any start up from Odisha popular, at least on national level??
<br>
It's evident that a massive population of eastern Odisha is migrating to other parts of the country in search of job opportunities. This is all because this region is not home to a lot of start ups and not a lot of entrepreneurs consider to start a business or an industry here. Hence it is extremely important to create a platform for experts, interested start ups and interns who are looking for start ups to talk to each other and exchange ideas so that more and more number of entrepreneurs take notice of this place and industries are developed.
<br>
It is a many-many kind of interaction with win-win situational probabilities for both sides. Start ups will post for their internship offers, and interns at the same time can apply for internships of their field of interest.
<br>
How can interns find the right choices for them, and vive versa?
<br>
Start ups will be having a list of requirements, basing on which the applicants will be filtered. The applicants can apply for internships accordingly; this will help them to filter the company of their choice. Similarly, each intern will have a history of internships and courses that he has attended, which will help the start ups to shortlist the right intern.
<br>
We are planning to extend our scope beyond internships in near future. Any suggestions for us are always welcome.

For any queries, contact the GePo.com.</p>
    </div>

  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</body>
</html>
