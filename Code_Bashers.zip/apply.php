<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Apply</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link href="css/styles.css" rel="stylesheet" type="text/css" />
</head>
<body>

<div class="header-wrap">
	<div class="logo">
		<h1>GE-PO</h1>
    </div>
</div><!---header-wrap-End--->
<div class="menu-wrap">
  <div class="menu">
    <ul>
          	<li><a href="index.php" >Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="apply.php" class="active">Apply</a></li>
            <li><a href="post.php">Post</a></li>
            <li><a href="contact.php">Contact</a></li>
    </ul>
  </div>
  <div class="socia-wrap">
    <div class="socail">
      <ul>
        <li><a href="#"><img src="images/facebook.png" alt="" /></a></li>
        <li><a href="#"><img src="images/twwtter.png" alt="" /></a></li>
        <li><a href="#"><img src="images/linkedin.png" alt="" /></a></li>
      </ul>
    </div>
  </div>
</div>
<!---menu-wrap-End--->
  <div class="jumbotron" style="	background-color:black;">
  <h1   style="color:white;font-family:impact;font-size: 36pt;"><CENTER>	APPLY FOR INTERNSHIPS</CENTER></h1>
  <font style="ont-family:cursive;font-size:15pt" ><CENTER>A GRAND WELCOME....... TO ALL THE INTERNS!!<br> ARE YOU EXCITED FOR APPLYING FOR DIFFERENT INTERNSHIP?<br>BELOW YOU CAN FIND ALL THE COMPANIES WHERE YOU CAN DO YOUR INTERNSHIP AND GAIN INDUSTRY EXPERIENECE.</CENTER></font>

</div>
	<div class="container" style="font-family:impact;opacitty:0.6">
<div class="row row-cols-1 row-cols-md-3">



  <div class="col mb-4" >
    <div class="card" >
      <div class="card-body">
        <div style="font-size:22px; color:red" >
Company->ABC TECHNOLOGY<br>
Post->Frontend Developer<br>Time->3 months<br>Stipened->5000 per month
<br><br><button class="button">apply ow</button>
      </div>
    </div>
  </div>
  </div>



  <div class="col mb-4">
    <div class="card">
      <div class="card-body" >
	  <div style="font-size:22px; color:red">
company->QUAL INFOMATICA<br>
post->os Developer<br>time->6 months<br>stipened->10000 per month
<br><br><button class="button">apply now</button>
      </div>
    </div>
	</div>
  </div>
  


  <div class="col mb-4">
    <div class="card">
      <div class="card-body">
	  <div style="font-size:22px; color:red">
        company->MICROSOFT<br>
post->Web developer<br>time->1 months<br>stipened->0
<br><br><button class="button">apply now</button>
      </div>
    </div>
  </div>
</div>


  <div class="col mb-4">
    <div class="card">
      <div class="card-body"> 
	  <div style="font-size:22px; color:red">
company->MICROCHIP<br>
post->IOT expertise<br>time->4 months<br>stipened->7500 per month
<br><br><button class="button">apply now</button>
      </div>
    </div>
  </div>
  </div>


  <div class="col mb-4">
    <div class="card">
      <div class="card-body"> 
	  <div style="font-size:22px; color:red">
        company->WILSON SORT INC.<br>
post->PHP DEVELOPER<br>time->2 months<br>stipened->3000 per month
<br><br><button class="button">apply now</button>
      </div>
    </div>
  </div>
</div>


  <div class="col mb-4">
    <div class="card">
      <div class="card-body"> 
	  <div style="font-size:22px; color:red">
company->GitHuB<br>
post->frontend developer<br>time->5 months<br>stipened->9500 per month
<br><br><button class="button">apply now</button>
      </div>
    </div>
  </div>
  </div>

</div></div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</body>
</html>
