<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Apply</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<link href="css/styles.css" rel="stylesheet" type="text/css" />
<meta name="viewport" content="width=device-width, initial-scale=1">

</head>

<body>
<div class="header-wrap">
	<div class="logo">
		<h1><u><i><b>GE-PO</b></i></u></h1>
    </div>
</div><!---header-wrap-End--->

<div class="menu-wrap">
	<div class="menu">
		<ul>
          	<li><a href="index.php" class="active">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="apply.php">Apply</a></li>
            <li><a href="post.php">Post</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
    </div>
    
    <div class="socia-wrap">
	<div class="socail">
		<ul>
        	<li><a href="#"><img src="images/facebook.png" alt="" /></a></li>
            <li><a href="#"><img src="images/twwtter.png" alt="" /></a></li>
            <li><a href="#"><img src="images/linkedin.png" alt="" /></a></li>
		</ul>
	</div>
</div>
</div><!---menu-wrap-End--->



    	<div  style="text-align:center"><img style=" width:820px" src="images/image1.png" alt="" /></div>
<br><br><br>

  <div class="jumbotron" style="	background-color:black;">
  <font style="ont-family:cursive;font-size:18pt" ><CENTER>Appear the quiz that is nearest to your field of expertise, if you do not have any industrial experience.</CENTER></font></div>
		<div >
	<h2></h2>
		<ul style="padding-left:300px;font-size:30px">
          	<br><li><a href="web.php "><u>1.click here for HTML quiz</u></a></li>
            <br><li><a href="os.php"><u>2.click here for OPERATING SYSYTEM quiz</u></a></li>
            <br><li><a href="database.php"><u>3.click here for DATABASE quiz</u></a></li>
            <br><li><a href="ml.php"><u>4.click here for MACHINE LEARING quiz</u></a></li>
			<br><li><a href="iot.php"><u>5.click here for  INTERNET OF THING  quiz</u></a></li>
            <br><li><a href="ai.php"><u>6.click here for ARTIFICIAL INTELEGENCE quiz</u></a></li>
        </ul>

		</div>



<div class="footer-wrap">
  <div class="wrap">
    <div class="panel marRight30">    
    <div class="panel">
      <div class="title">
        <h1>Contact us </h1>
      </div>
      <div class="cotact">
        <ul>
          <li><img src="images/icon6.png" alt="" />+91 7873509327</li>
          <li><img src="images/icon7.png" alt="" /><a href="mailto:dibya911das@gmail.com">dibya911das@gmil.com</a></li>
          <li><img src="images/icon8.png" alt="" />DIBYA RANJAN DAS</li>
        </ul>
      </div>
    </div>
    <div class="clearing"></div>
  </div>
</div><!---footer-wrap--->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
 <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
</body>
</html>
